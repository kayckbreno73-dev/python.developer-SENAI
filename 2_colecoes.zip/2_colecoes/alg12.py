numeros=["9,4,4,7,2,1,7,9,3,5,8,8,8,2,4,6"]
print(numeros)