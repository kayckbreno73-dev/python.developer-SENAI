mercados = ["ações","opções","futuro","dolar","ouro","criptomoedas"]
print(mercados)
print(mercados[0:3])
print("futuro" in mercados)
print("senai" in mercados)
print("minha sogra" in mercados)