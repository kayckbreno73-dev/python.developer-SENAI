#elabore um programa que leia um numero verifique se o numero é par ou ímpar e mostre a mensagem na tela
numero=float(input("digite seu numero:"))
if numero %2 ==0:
    print("seu numero é par")
else:
    print("seu número é impar")