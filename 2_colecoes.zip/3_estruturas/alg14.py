nome="alice"
if nome=="alice":
    print(f"olá {nome}")
else:
    print("você é estranho")