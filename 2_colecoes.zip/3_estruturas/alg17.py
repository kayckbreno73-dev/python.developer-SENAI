#ler tres notas de um aluno
#ler o nome de um aluno
#ler numero da turma
#ler 3 notas
nome=input("qual seu nome?")
turma=input("qual sua turma?")
nota1=float(input("qual sua primeira nota?"))
nota2=float(input("qual sua segunda nota?"))
nota3=float(input("qual sua terceira nota?"))
media= (nota1 + nota2 + nota3)/3
print(f"olá {nome}")
print(f"sua turma é:{turma}")
print(f"sua media é {media}")
if media>=70:
    print(f"parabens {nome}, voce foi aprovado!")
else:
    print(f"que pena {nome}, voce esta reprovado")




