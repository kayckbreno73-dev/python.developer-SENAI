numero1=int(input("digite o primeiro numero"))
numero2=int(input("digite o segundo numero"))
if numero1>numero2:
    print(f"{numero1} é maior que {numero2}")
elif numero2>numero1:
    print(f"{numero2} é maior que {numero1}")
else:
    print("os resultados são iguais")