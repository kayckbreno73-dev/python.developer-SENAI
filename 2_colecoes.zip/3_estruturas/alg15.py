numero=int(input("digite seu numero"))
if numero > 0:
    print("seu numero é positivo")
elif numero <0:
    print("seu numero é negativo")
else:
    print("seu numero é nulo")
