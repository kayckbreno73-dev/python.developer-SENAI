diasemana=int(input("qual o dia da semana?"))
if diasemana == 1:
    print("domingo")
elif diasemana ==2:
    print("segunda")
elif diasemana ==3:
    print("terça")
elif diasemana ==4:
    print("quarta")
elif diasemana==5:
    print("quinta")
elif diasemana ==6:
    print("sexta")
elif diasemana==7:
    print("sabado")
else:
    print("invalido")