#calculadora de IMC
peso = float(input("qual seu peso em kg?"))
altura = float(input("qual sua altura em metros?"))
resultado = peso / (altura **2 )
print("seu IMC é :", resultado)
