#algoritmo é uma sequencia de passos
print("Hello World!")

