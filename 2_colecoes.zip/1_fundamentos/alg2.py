 #calculadora basica
numero1 = float(input("digite seu numero:"))
numero2 = float(input("digite outro numero:"))
operacoes = input("qual a operacao? (+,*,/,-)")
if operacoes == "+":
    resultado = numero1 + numero2
if operacoes == "-":
    resultado = numero1 - numero2
if operacoes == "/":
    resultado = numero1 / numero2
if operacoes == "*":
    resultado = numero1 * numero2 
print("seu resultado é", resultado)
