senha= float(input("qual sua senha?"))
if senha == 12345678:
    print("sua senha está correta")