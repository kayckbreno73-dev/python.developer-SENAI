nome=input("qual a seu nome?")
idade=float(input("qual sua idade?"))
if idade>18:
    r=(f"o {nome} é maior de idade\n")
else:
    r=(f"o {nome} é menor de idade \n")
print(r)