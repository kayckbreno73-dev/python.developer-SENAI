primeira_nota = float(input("digite a nota"))
segunda_nota= float(input("digite a outra nota"))
terceira_nota=float(input("digite a ultima nota"))

soma = primeira_nota + segunda_nota + terceira_nota
print("A soma é:",soma)
media =soma/3
print ("a media é", media)
if media> 6:
    print("parabens, vc passou")
else:
    print("voce nao passou")